<?php 

	require_once("framework/SleekDB/SleekDB.php");
	require_once('config.php');
	require_once('functions.php');
	require_once('controller.php');

?>